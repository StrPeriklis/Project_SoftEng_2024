package com.example.omnibus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmnibusApplicationTests {

	@Test
	void contextLoads() {
	}

}
